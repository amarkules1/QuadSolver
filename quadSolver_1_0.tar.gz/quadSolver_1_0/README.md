# QuadSolver
A C program which solves quadratic equations in the form ax^2 + bx + c = 0
