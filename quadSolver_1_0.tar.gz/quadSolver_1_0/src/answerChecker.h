#ifndef ANSWERCHECKER_H
#define ANSWERCHECKER_H
#include <math.h>

int checkAnswer(double a, double b, double c, double x);

#endif