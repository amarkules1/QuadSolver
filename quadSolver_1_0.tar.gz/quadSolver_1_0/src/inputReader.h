typedef struct
{
    char* A;
    char* B;
    char* C;
} quadConstants;
quadConstants* readFromConsole();
