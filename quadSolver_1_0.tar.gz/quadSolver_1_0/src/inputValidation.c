#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "inputValidation.h"

/**This method could be implemented after Grant's initial input validation
 * things to check:
 * check if float
 * check precision
 * 
 * 
 * 
 * **/
float validateInput(char * input){

float number; 

if(sscanf(input, "%f", &number) == 1) {
  
} else {
  printf("Error: not a number.\n");
  return 0.0/0.0;
}
return number;
}