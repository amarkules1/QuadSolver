#ifndef INPUTVALIDATION_H
#define INPUTVALIDATION_H

float validateInput(char * input); 

#endif